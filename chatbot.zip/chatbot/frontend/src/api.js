import axios from 'axios';

const API_URL = 'http://localhost:8000/query'; // Your backend URL

export const fetchChatbotResponse = async (query) => {
  try {
    const response = await axios.post(API_URL, { query });
    return response.data.message;
  } catch (error) {
    console.error('Error fetching response from backend:', error);
    throw error;
  }
};
