import React, { useState } from 'react';
import axios from 'axios';

const Chatbot = () => {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState([]);

  // Handle user input submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    const newMessage = { sender: 'user', text: query };
    setMessages([...messages, newMessage]);

    // Call backend API to process query
    try {
      const response = await axios.post('http://localhost:8000/query', { query });
      const chatbotResponse = { sender: 'chatbot', text: response.data.message };
      setMessages([...messages, newMessage, chatbotResponse]);
    } catch (error) {
      console.error('Error fetching response from backend:', error);
    }

    setQuery('');
  };

  return (
    <div>
      <div className="chat-window">
        {messages.map((message, index) => (
          <div key={index} className={message.sender}>
            <strong>{message.sender === 'user' ? 'You' : 'Chatbot'}:</strong> {message.text}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask me anything..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
};

export default Chatbot;
