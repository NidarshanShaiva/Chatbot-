-- Create the Supplier table
CREATE TABLE suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    contact_info VARCHAR(255),
    product_categories_offered TEXT
);

-- Create the Product table
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    brand VARCHAR(255),
    price DECIMAL(10, 2),
    category VARCHAR(255),
    description TEXT,
    supplier_id INT,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
);

-- Insert sample data
INSERT INTO suppliers (name, contact_info, product_categories_offered)
VALUES
    ('Supplier 1', 'supplier1@example.com', 'Laptops, Tablets'),
    ('Supplier 2', 'supplier2@example.com', 'Smartphones, Accessories');

INSERT INTO products (name, brand, price, category, description, supplier_id)
VALUES
    ('Product 1', 'Brand A', 999.99, 'Laptop', 'A high-performance laptop', 1),
    ('Product 2', 'Brand B', 499.99, 'Smartphone', 'A budget smartphone', 2);
